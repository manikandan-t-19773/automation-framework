var browserWorkerPolyFill = function Od(e){return e.on=e.addEventListener,e.off=e.removeEventListener,e};
browserWorkerPolyFill(self);
var e=function(){function e(){this.listeners={}}var t=e.prototype
return t.on=function(e,t){this.listeners[e]||(this.listeners[e]=[]),this.listeners[e].push(t)},t.off=function(e,t){return!!this.listeners[e]&&(t=this.listeners[e].indexOf(t),this.listeners[e]=this.listeners[e].slice(0),this.listeners[e].splice(t,1),-1<t)},t.trigger=function(e){var t=this.listeners[e]
if(t)if(2===arguments.length)for(var i=t.length,s=0;s<i;++s)t[s].call(this,arguments[1])
else for(var r=Array.prototype.slice.call(arguments,1),n=t.length,a=0;a<n;++a)t[a].apply(this,r)},t.dispose=function(){this.listeners={}},t.pipe=function(e){this.on("data",(function(t){e.push(t)}))},e}()

;/*! @name pkcs7 @version 1.0.4 @license Apache-2.0 */
/*! @name aes-decrypter @version 4.0.2 @license Apache-2.0 */let t=null
class i{constructor(e){let i,s,r
t=t||function(){var e=[[[],[],[],[],[]],[[],[],[],[],[]]],t=e[0],i=e[1],s=t[4],r=i[4]
let n,a,o
var l,d,h,u=[],c=[]
let p,m
for(n=0;n<256;n++)c[(u[n]=n<<1^283*(n>>7))^n]=n
for(a=o=0;!s[a];a^=l||1,o=c[o]||1)for(h=(h=o^o<<1^o<<2^o<<3^o<<4)>>8^255&h^99,m=16843009*u[d=u[l=u[r[s[a]=h]=a]]]^65537*d^257*l^16843008*a,p=257*u[h]^16843008*h,n=0;n<4;n++)t[n][a]=p=p<<24^p>>>8,i[n][h]=m=m<<24^m>>>8
for(n=0;n<5;n++)t[n]=t[n].slice(0),i[n]=i[n].slice(0)
return e}(),this._tables=[[t[0][0].slice(),t[0][1].slice(),t[0][2].slice(),t[0][3].slice(),t[0][4].slice()],[t[1][0].slice(),t[1][1].slice(),t[1][2].slice(),t[1][3].slice(),t[1][4].slice()]]
var n=this._tables[0][4],a=this._tables[1],o=e.length
let l=1
if(4!==o&&6!==o&&8!==o)throw new Error("Invalid aes key size")
var d=e.slice(0),h=[]
for(this._key=[d,h],i=o;i<4*o+28;i++)r=d[i-1],(i%o==0||8===o&&i%o==4)&&(r=n[r>>>24]<<24^n[r>>16&255]<<16^n[r>>8&255]<<8^n[255&r],i%o==0)&&(r=r<<8^r>>>24^l<<24,l=l<<1^283*(l>>7)),d[i]=d[i-o]^r
for(s=0;i;s++,i--)r=d[3&s?i:i-4],h[s]=i<=4||s<4?r:a[0][n[r>>>24]]^a[1][n[r>>16&255]]^a[2][n[r>>8&255]]^a[3][n[255&r]]}decrypt(e,t,i,s,r,n){var a,o,l=this._key[1]
let d,h=e^l[0],u=s^l[1],c=i^l[2],p=t^l[3]
var m=l.length/4-2
let g,f=4
var y=(e=this._tables[1])[0],_=e[1],v=e[2],b=e[3],T=e[4]
for(g=0;g<m;g++)d=y[h>>>24]^_[u>>16&255]^v[c>>8&255]^b[255&p]^l[f],a=y[u>>>24]^_[c>>16&255]^v[p>>8&255]^b[255&h]^l[f+1],o=y[c>>>24]^_[p>>16&255]^v[h>>8&255]^b[255&u]^l[f+2],p=y[p>>>24]^_[h>>16&255]^v[u>>8&255]^b[255&c]^l[f+3],f+=4,h=d,u=a,c=o
for(g=0;g<4;g++)r[(3&-g)+n]=T[h>>>24]<<24^T[u>>16&255]<<16^T[c>>8&255]<<8^T[255&p]^l[f++],d=h,h=u,u=c,c=p,p=d}}class s extends e{constructor(){super(e),this.jobs=[],this.delay=1,this.timeout_=null}processJob_(){this.jobs.shift()(),this.jobs.length?this.timeout_=setTimeout(this.processJob_.bind(this),this.delay):this.timeout_=null}push(e){this.jobs.push(e),this.timeout_||(this.timeout_=setTimeout(this.processJob_.bind(this),this.delay))}}function r(e){return e<<24|(65280&e)<<8|(16711680&e)>>8|e>>>24}class n{constructor(e,t,i,a){var o=n.STEP,l=new Int32Array(e.buffer)
let d=new Uint8Array(e.byteLength),h=0
for(this.asyncStream_=new s,this.asyncStream_.push(this.decryptChunk_(l.subarray(h,h+o),t,i,d)),h=o;h<l.length;h+=o)i=new Uint32Array([r(l[h-4]),r(l[h-3]),r(l[h-2]),r(l[h-1])]),this.asyncStream_.push(this.decryptChunk_(l.subarray(h,h+o),t,i,d))
this.asyncStream_.push((function(){var e
a(null,(e=d).subarray(0,e.byteLength-e[e.byteLength-1]))}))}static get STEP(){return 32e3}decryptChunk_(e,t,s,n){return function(){var a=function(e,t,s){var n,a,o,l,d=new Int32Array(e.buffer,e.byteOffset,e.byteLength>>2),h=new i(Array.prototype.slice.call(t)),u=(t=new Uint8Array(e.byteLength),new Int32Array(t.buffer))
let c,p,m,g,f
for(c=s[0],p=s[1],m=s[2],g=s[3],f=0;f<d.length;f+=4)n=r(d[f]),a=r(d[f+1]),o=r(d[f+2]),l=r(d[f+3]),h.decrypt(n,a,o,l,u,f),u[f]=r(u[f]^c),u[f+1]=r(u[f+1]^p),u[f+2]=r(u[f+2]^m),u[f+3]=r(u[f+3]^g),c=n,p=a,m=o,g=l
return t}(e,t,s)
n.set(a,e.byteOffset)}}}var a="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};(a=(a="undefined"!=typeof window?window:void 0!==a?a:"undefined"!=typeof self?self:{}).BigInt||Number)("0x1"),a("0x100"),a("0x10000"),a("0x1000000"),a("0x100000000"),a("0x10000000000"),a("0x1000000000000"),a("0x100000000000000"),a("0x10000000000000000"),a=new Uint16Array([65484]),(a=new Uint8Array(a.buffer,a.byteOffset,a.byteLength))[0],self.onmessage=function(e){let t=e.data
e=new Uint8Array(t.encrypted.bytes,t.encrypted.byteOffset,t.encrypted.byteLength)
var i=new Uint32Array(t.key.bytes,t.key.byteOffset,t.key.byteLength/4),s=new Uint32Array(t.iv.bytes,t.iv.byteOffset,t.iv.byteLength/4)
new n(e,i,s,(function(e,i){self.postMessage(function(e){let t={}
return Object.keys(e).forEach((i=>{var s,r=e[i]
s=r,("function"===ArrayBuffer.isView?ArrayBuffer.isView(s):s&&s.buffer instanceof ArrayBuffer)?t[i]={bytes:r.buffer,byteOffset:r.byteOffset,byteLength:r.byteLength}:t[i]=r})),t}({source:t.source,decrypted:i}),[i.buffer])}))}